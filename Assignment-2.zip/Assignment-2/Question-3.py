# q3.py

ch = input('Enter an alphabet: ')
if ch.isupper():
    print('Uppercase alphabet')
else:
    print('Lowercase alphabet')